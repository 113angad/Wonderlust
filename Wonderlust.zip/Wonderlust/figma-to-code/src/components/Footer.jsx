
import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">
      <a href="/" className="footer-logo">
        Wanderlust
      </a>

      <div className="footer-links">
        <a href="#privacy">Privacy Policy</a>
        <a href="#terms">Terms of Service</a>
      </div>

      <div className="footer-links secondary-links">
        <a href="#contact">Contact Us</a>
        <a href="#faq">FAQ</a>
      </div>

      <p className="copyright">
        © 2024 Wanderlust Travel Agency. All rights reserved.
      </p>

      <a href="#top" className="back-to-top">
        Back to Top ↑
      </a>
    </footer>
  );
}

export default Footer;
