
import "./Header.css";

function Header() {
  return (
    <header className="header">
      <h2>Get coding, faster</h2>

      <p>
        Dev Mode simplifies handoff, speeds up inspection,
        and integrates with tools like VS Code and Storybook.
      </p>

      <button className="request-btn">
        Request access
      </button>
    </header>
  );
}

export default Header;
