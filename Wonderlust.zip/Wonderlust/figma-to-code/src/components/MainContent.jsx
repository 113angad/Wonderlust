import "./MainContent.css";
const destinations = [
  {
    name: "Maldives",
    price: "From $1,299",
    image: "/images/maldives.png",
    description:
      "Experience ultimate luxury in crystal clear waters and pristine white sand beaches.",
  },
  {
    name: "Swiss Alps",
    price: "From $899",
    image: "/images/swiss-alps.png",
    description:
      "Hit the slopes or relax in a cozy chalet with breathtaking mountain views.",
  },
  {
    name: "Safari Adventure",
    price: "From $2,499",
    image: "/images/safari.png",
    description:
      "Witness extraordinary wildlife in their natural habitat across vast plains.",
  },
  {
    name: "Tokyo City",
    price: "From $1,599",
    image: "/images/tokyo.png",
    description:
      "Immerse yourself in a vibrant metropolis blending deep tradition with modern tech.",
  },
];

function MainContent() {
  return (
    <main>
      {/* Hero section */}
      <section className="hero">
        <div className="hero-content">
          <h1>
            WELCOME TO
            <br />
            DREAM TRAVEL
          </h1>

          <p>
            Find your next adventure here. Explore pristine beaches,
            towering mountains, and vibrant cities with our curated
            travel experiences.
          </p>

          <a href="#destinations" className="book-btn">
            Book Now <span aria-hidden="true">→</span>
          </a>
        </div>
      </section>

      {/* Featured destinations */}
      <section className="destinations" id="destinations">
        <div className="section-heading">
          <h2>Featured Destinations</h2>
          <p>
            Discover our most popular travel spots curated just for you.
          </p>
        </div>

        <div className="destination-grid">
          {destinations.map((destination) => (
            <article className="destination-card" key={destination.name}>
              <div className="destination-image">
                <img src={destination.image} alt={destination.name} />
                <span className="price-tag">{destination.price}</span>
              </div>

              <div className="destination-info">
                <h3>{destination.name}</h3>
                <p>{destination.description}</p>
                <a href="#about" className="learn-btn">
                  Learn More
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* About us */}
      <section className="about" id="about">
        <h2>About Us</h2>

        <div className="about-card">
          <p>
            We are a passionate team of travelers dedicated to helping
            you find the perfect getaway. From sunny beaches to snowy
            mountains, we handle all the details so you can enjoy the
            journey. Our mission is to make exploration effortless,
            providing curated itineraries and seamless booking
            experiences that let you focus on making memories.
          </p>
        </div>
      </section>
    </main>
  );
}

export default MainContent;
